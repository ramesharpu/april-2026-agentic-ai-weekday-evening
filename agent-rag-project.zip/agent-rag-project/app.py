from flask import Flask, render_template, request, jsonify

from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.vectorstores import FAISS
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

from langgraph.graph import StateGraph, END
from typing import TypedDict

from dotenv import load_dotenv
import os

# Flask app initialization
app = Flask(__name__)

# Loading the API key
load_dotenv()
KEY = os.getenv("OPENAI_API_KEY")

# document file loading ==> text document
loader = TextLoader("data.txt")
documents = loader.load()

text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
docs = text_splitter.split_documents(documents)

# Embeddings
embeddings = OpenAIEmbeddings()

# Vector store
vectorstore = FAISS.from_documents(docs, embeddings)
retriever = vectorstore.as_retriever()


# llm 
llm = ChatOpenAI(model="gpt-5.4-mini", temperature=0)


# prompt
prompt = ChatPromptTemplate.from_template(
    "Answer the question based only on the context:\n\n{context}\n\nQuestion: {question}"
)

# Define graph
class GraphState(TypedDict):
    question: str
    context: str
    answer: str

# Nodes
def retrieve(state: GraphState):
    docs = retriever.invoke(state["question"])
    context = "\n\n".join(doc.page_content for doc in docs)
    return {"context": context}

def generate(state: GraphState):
    chain = prompt | llm | StrOutputParser()
    answer = chain.invoke(
        {
            "context": state["context"],
            "question": state["question"]
        }
    )
    return {"answer": answer}

# Build the graph
graph = StateGraph(GraphState)

graph.add_node("retrieve", retrieve)
graph.add_node("generate", generate)

graph.set_entry_point("retrieve")
graph.add_edge("retrieve", "generate")
graph.add_edge("generate", END)

# compile the graph
rag_app = graph.compile()


# Flask routes
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    question = request.json.get("question")
    result = rag_app.invoke({"question": question})
    return jsonify({"answer": result["answer"]})

# Running the Flask app
if __name__ == "__main__":
    app.run(debug=True)

# # run the query
# query = "what is this document about?"

# res = app.invoke({"question": query})

# print(res["answer"])
